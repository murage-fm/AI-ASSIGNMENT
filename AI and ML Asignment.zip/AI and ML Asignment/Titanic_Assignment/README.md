
---

## ⚙️ Methodology

The analysis follows a structured data science workflow:

1. **Data Cleaning**
   - Handling missing values and inconsistencies
   - Managing outliers where necessary

2. **Feature Engineering**
   - Creating new meaningful variables such as:
     - FamilySize
     - IsAlone
     - Title
     - Deck
     - AgeGroup
     - FarePerPerson

3. **Data Transformation**
   - Encoding categorical variables
   - Applying transformations to reduce skewness in numerical features

4. **Feature Selection**
   - Using correlation analysis
   - Applying Random Forest feature importance to identify key predictors

---

## 🧩 Engineered Features

The following features were created to enhance predictive performance:

- FamilySize  
- IsAlone  
- Title  
- Deck  
- AgeGroup  
- FarePerPerson  
- FareLog  
- AgeLog  
- Pclass_Fare  

---

## 🧹 Data Cleaning Strategy

Key preprocessing decisions include:

- Missing **Age** values filled using the median
- Missing **Embarked** values filled using the mode
- **Cabin** information simplified by extracting deck-level data and using indicators
- **Fare** values capped using the IQR method and transformed using a logarithmic scale

---

## 📊 Key Insights

- Passenger class, gender, title, fare-related variables, and family structure were among the strongest survival indicators
- Log transformation helped reduce skewness in the Fare distribution
- Newly engineered features such as Title and Deck provided additional predictive value beyond original variables

---

## ▶️ How to Run the Project

Install dependencies:

```bash
pip install -r requirements.txt